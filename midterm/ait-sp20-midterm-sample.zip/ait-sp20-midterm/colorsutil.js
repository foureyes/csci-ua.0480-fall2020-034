// TODO: Questions 1 and 2

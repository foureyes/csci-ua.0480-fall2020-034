const express = require('express');
const app = express();
const session = require('express-session');

const sessionOptions = { 
    secret: 'secret for signing session id', 
    saveUninitialized: false, 
    resave: false 
};

app.use(session(sessionOptions));

app.set('view engine', 'hbs');

// TODO: Questions 3 to 6

module.exports = app.listen(3000);

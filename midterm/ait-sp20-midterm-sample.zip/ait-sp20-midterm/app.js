const express = require('express');
const app = express();
const session = require('express-session');

const sessionOptions = { 
    secret: 'secret for signing session id', 
    saveUninitialized: false, 
    resave: false 
};

app.use(session(sessionOptions));

app.set('view engine', 'hbs');

// TODO: Questions 3 to 6


// KEEP LINE BELOW
// (DO NOT ADD EXTRA CALL TO LISTEN)
// DO NOT PLACE IN CALLBACK
module.exports = app.listen(3000);



